from flask_sqlalchemy import SQLAlchemy

# Initialize the Flask-SQLAlchemy extension instance
db = SQLAlchemy()